import "./styles.css";
import List from "./List";

export default function App() {
  return (
    <div>
      <h3 className="title">Ecommerce Store</h3>
      <List />
    </div>
  );
}
